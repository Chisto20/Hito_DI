from django.shortcuts import render
from coches.models import Coche

# Create your views here.
def coches_index(request):
    coches = Coche.objects.all()
    context ={
        'coches' : coches
    }
    return render(request, 'coches_index.html', context)

def coches_detail(request, pk):
    coche = Coche.objects.get(pk=pk)
    context = {
        'coche': coche
    }
    return render(request, 'coches_detail.html', context)

def home(request):
    return render(request, 'home.html', {})

def compra(request):
    return render(request, 'compra.html', {})

def comprado(request):
    return render(request, 'comprado.html', {})
