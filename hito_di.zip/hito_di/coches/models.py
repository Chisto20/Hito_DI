from django.db import models

# Create your models here.

class Coche(models.Model):
    nom = models.CharField(max_length=100)
    des = models.TextField()
    dat = models.CharField(max_length=20)
    image = models.FilePathField(path="/img")
