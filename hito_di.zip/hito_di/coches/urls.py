from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('coches/', views.coches_index, name='coches_index'),
    path("<int:pk>/", views.coches_detail, name="coches_detail"),
    path('compra/', views.compra, name='compra'),
    path('comprado/', views.comprado, name='comprado'),
]