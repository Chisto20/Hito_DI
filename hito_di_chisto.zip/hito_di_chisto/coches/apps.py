from django.apps import AppConfig


class CochesConfig(AppConfig):
    name = 'coches'
